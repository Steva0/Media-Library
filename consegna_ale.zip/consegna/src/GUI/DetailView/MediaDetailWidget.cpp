#include "MediaDetailWidget.h"

#include <QHBoxLayout>
#include <QPixmap>
#include <QResizeEvent>
#include <QString>
#include <QVBoxLayout>

namespace gui {

MediaDetailWidget::MediaDetailWidget(QWidget* parent) : IMediaDetailWidget(parent), coverPixmap_() {
  auto* mainLayout = new QHBoxLayout(this);

  leftWidget_ = new QWidget(this);
  leftLayout_ = new QVBoxLayout(leftWidget_);
  leftWidget_->setLayout(leftLayout_);

  titleLabel_ = new QLabel(this);
  spacerLabel_ = new QLabel(this);  
  releaseLabel_ = new QLabel("Anno di uscita: ", this);
  languageLabel_ = new QLabel("Lingua: ", this);
  favouriteLabel_ = new QLabel("Preferito: ", this);
  genresLabel_ = new QLabel("Generi: ", this);
  notesLabel_ = new QLabel("Note: ", this);

  leftLayout_->addWidget(titleLabel_);
  leftLayout_->addWidget(releaseLabel_);
  leftLayout_->addWidget(languageLabel_);
  leftLayout_->addWidget(favouriteLabel_);
  leftLayout_->addWidget(genresLabel_);

  mainLayout->addWidget(leftWidget_, 2, Qt::AlignTop);

  coverLabel_ = new QLabel(this);
  coverLabel_->setAlignment(Qt::AlignCenter);
  coverLabel_->setScaledContents(false);  // facciamo scalare a mano noi
  mainLayout->addWidget(coverLabel_, 1);

  releaseLabel_->setWordWrap(true);
  languageLabel_->setWordWrap(true);
  favouriteLabel_->setWordWrap(true);
  genresLabel_->setWordWrap(true);
  notesLabel_->setWordWrap(true);
}

void MediaDetailWidget::setMedia(const media::Media* media) {
  if (!media) {
    clearFields();
    return;
  }

  // Title: supponiamo non possa mai essere vuoto
  titleLabel_->setText(QString::fromStdString(media->getTitle()));

  // Release year: se uguale a valore base, campo vuoto
  int releaseYear = media->getRelease();
  if (releaseYear == std::numeric_limits<int>::min()) {
    releaseLabel_->setText("Anno di uscita: ");
  } else {
    releaseLabel_->setText(QString("Anno di uscita: %1").arg(releaseYear));
  }

  // Language: se stringa vuota o solo spazi, campo vuoto
  QString language = QString::fromStdString(media->getLanguage()).trimmed();
  if (language.isEmpty()) {
    languageLabel_->setText("Lingua: ");
  } else {
    languageLabel_->setText(QString("Lingua: %1").arg(language));
  }

  // Favourite: true/false, sempre visualizzato
  favouriteLabel_->setText(QString("Preferito: %1").arg(media->isFavourite() ? "Yes" : "No"));

  // Genres: se vuoto, campo vuoto
  const auto& genres = media->getGenres();
  if (genres.empty()) {
    genresLabel_->setText("Generi: ");
  } else {
    QStringList genresList;
    for (const auto& g : genres) {
      genresList << QString::fromStdString(g);
    }
    genresLabel_->setText(QString("Generi: %1").arg(genresList.join(", ")));
  }

  // Notes: se vuoto o solo spazi, campo vuoto
  QString notes = QString::fromStdString(media->getNotes()).trimmed();
  if (notes.isEmpty()) {
    notesLabel_->setText("Note: ");
  } else {
    notesLabel_->setText(QString("Note: %1").arg(notes));
  }

  // Carico immagine
  QPixmap pixmap(QString::fromStdString(media->getImgPath()));
  if (pixmap.isNull()) {
    pixmap = QPixmap(":/assets/matita.jpg");
  }
  coverPixmap_ = pixmap;

  updateCoverPixmap();
}

void MediaDetailWidget::clearFields() {
  titleLabel_->setText("");
  releaseLabel_->setText("Anno di uscita: ");
  languageLabel_->setText("Lingua: ");
  favouriteLabel_->setText("Preferito: ");
  genresLabel_->setText("Generi: ");
  notesLabel_->setText("Note: ");

  coverPixmap_ = QPixmap(":/assets/matita.jpg");
  updateCoverPixmap();
}

void MediaDetailWidget::resizeEvent(QResizeEvent* event) {
  IMediaDetailWidget::resizeEvent(event);
  updateCoverPixmap();
  updateTextFontSize();
}

void MediaDetailWidget::updateCoverPixmap() {
  if (coverPixmap_.isNull()) {
    coverLabel_->clear();
    return;
  }

  // Limiti massimi
  int maxWidth  = width() / 3;
  int maxHeight = height() / 2;

  // Scala mantenendo il rapporto d'aspetto entro entrambi i limiti
  QPixmap scaled = coverPixmap_.scaled(maxWidth, maxHeight, 
                                       Qt::KeepAspectRatio, 
                                       Qt::SmoothTransformation);

  coverLabel_->setPixmap(scaled);
}


void MediaDetailWidget::updateTextFontSize() {
  if (!leftWidget_) return;

  int totalHeight = height();

  int totalLabels = 6; 
  int spaceForText = totalHeight * 0.9;

  int titleLabelFont_Size = std::clamp(spaceForText / 12, 16, 36);  
  int otherFontSize = std::clamp(spaceForText / (totalLabels * 2), 10, 24);  

  titleLabelFont_.setPointSize(titleLabelFont_Size);
  titleLabelFont_.setBold(true);
  titleLabel_->setFont(titleLabelFont_);

  normalLabelFont_.setPointSize(otherFontSize);
  normalLabelFont_.setBold(false);

  releaseLabel_->setFont(normalLabelFont_);
  languageLabel_->setFont(normalLabelFont_);
  favouriteLabel_->setFont(normalLabelFont_);
  genresLabel_->setFont(normalLabelFont_);
  notesLabel_->setFont(normalLabelFont_);

  spacerLabel_->setFixedHeight(titleLabelFont_Size / 2);
}


}  // namespace gui
