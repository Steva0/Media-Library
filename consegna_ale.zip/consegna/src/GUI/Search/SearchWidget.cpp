#include "SearchWidget.h"

#include <QHBoxLayout>

#include "qsizepolicy.h"

namespace gui {
namespace search {
SearchWidget::SearchWidget(QWidget *parent)
  : QWidget(parent),
    input_(new InputBar(500, this)),
    advanced_search_(new QPushButton("Avanzata", this)),
    add_new_(new QPushButton("Aggiungi Nuovo", this)) {
  auto *layout = new QVBoxLayout(this);

  input_->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
  advanced_search_->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
  add_new_->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);

  add_new_->setProperty("verde", true);

  auto *advanced_wrapper = new QHBoxLayout;
  advanced_wrapper->addWidget(advanced_search_);
  advanced_wrapper->addStretch();

  auto *add_wrapper = new QHBoxLayout;
  add_wrapper->addStretch();
  add_wrapper->addWidget(add_new_);

  layout->addLayout(advanced_wrapper);
  layout->addWidget(input_);
  layout->addLayout(add_wrapper);

  layout->setAlignment(Qt::AlignTop | Qt::AlignLeft);

  connect(input_, &InputBar::timedEdit, this, [this]() {
  filter_.setTitle(input_->text().toStdString());
  emit simpleSearch(filter_);
  });
  connect(advanced_search_, &QAbstractButton::clicked, this, &SearchWidget::openAdvancedSearch);
  connect(advanced_search_, &QPushButton::clicked, this, &SearchWidget::advancedClicked);
  connect(add_new_, &QAbstractButton::clicked, this, &SearchWidget::addNewMedia);
}
}  // namespace search
}  // namespace gui
